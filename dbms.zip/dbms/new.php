
<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
 

$dir=$_SESSION['login'];
if(is_dir("files/$dir")){
$files = scandir("files/$dir");




for ($a = 2; $a < count($files); $a++)
{
    ?>
    <p>
        <!-- Displaying file name !-->
        <?php echo $files[$a]; ?>
        
        <!-- href should be complete file path !-->
        <!-- download attribute should be the name after it downloads !-->
        <a href="<?php echo 'files/'.$dir.'/'.$files[$a]; ?>" download="<?php echo $files[$a]; ?>">
            Download
        </a>
    </p>
    <?php
}
}
?>


    <?php

